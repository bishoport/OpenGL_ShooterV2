// This file is auto-generated, manual changes will be lost if the code is regenerated.

#include "geometries.hpp"

namespace mapbox {
namespace fixtures {

static const Fixture<short> issue131("issue131", 12, 1e-14, 0.000001, {
    {{3506,-2048},{7464,402},{-2048,2685},{-2048,-2048},{3506,-2048}},
    {{-2048,-37},{1235,747},{338,-1464},{-116,-1188},{-2048,-381},{-2048,-37}},
    {{-1491,-1981},{-1300,-1800},{-1155,-1981},{-1491,-1981}},
});

}
}
