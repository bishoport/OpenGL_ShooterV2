// This file is auto-generated, manual changes will be lost if the code is regenerated.

#include "geometries.hpp"

namespace mapbox {
namespace fixtures {

static const Fixture<short> filtered_bridge_jhl("filtered_bridge_jhl", 25, 1e-14, 0.000001, {
    {{22,14},{17,12},{5,12},{0,12},{0,0},{22,0}},
    {{9,4},{10,4},{10,3},{9,3}},
    {{6,9},{7,9},{7,8},{6,8}},
    {{7,10},{17,10},{17,5},{8,5}},
    {{13,4},{14,4},{14,3},{13,3}},
});

}
}
