// This file is auto-generated, manual changes will be lost if the code is regenerated.

#include "geometries.hpp"

namespace mapbox {
namespace fixtures {

static const Fixture<short> collinear_diagonal("collinear_diagonal", 14, 1e-14, 0.000001, {
    {{3468,1913},{3486,1884},{3413,1869},{3322,1869},{3413,1854},{3413,1869},{3486,1869},{3486,1884},{3504,1884},{3504,1869},{3432,1869},{3432,1854},{3395,1854},{3432,1839},{3432,1854},{3450,1839},{3341,1839},{3341,1825},{3195,1825},{3341,1810},{3341,1825},{3450,1825},{3523,1854},{3523,1913}},
});

}
}
