// This file is auto-generated, manual changes will be lost if the code is regenerated.

#include "geometries.hpp"

namespace mapbox {
namespace fixtures {

static const Fixture<short> bad_diagonals("bad_diagonals", 7, 1e-14, 0.000001, {
    {{440,4152},{440,4208},{296,4192},{368,4192},{400,4200},{400,4176},{368,4192},{296,4192},{264,4200},{288,4160},{296,4192}},
});

}
}
